# mysensors_connectors.pretty

Different kinds of connectors that we can use in mysensors projects